//Kamil Zambrowski
// I Pledge My Honor That I Have Abided By The Stevens Honor System

const bandData = require('./bands');
module.exports = { bands: bandData };