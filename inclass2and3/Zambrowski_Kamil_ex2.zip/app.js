// Kamil Zambrowski
// I Pledge My Honor That I Have Abided By The Stevens Honor System

const bands = require('./data/bands');
const connection = require('./config/mongoConnection');

const main = async () => {
    const band1 = await bands.addBand("someGuys", ["FirstGuy", "SecondGuy"], 2020, ["Rock"], "GuyMusic");
    console.log("someGuys has been added");
    console.log(band1);
    const band2 = await bands.addBand("someGals", ["FirstGal", "SecondGal", "ThirdGal"], 2000, ["Jazz", "Rap"], "GalMusic");
    console.log("someGals has been added");
    console.log(band2);
    const allBands = await bands.getAllBands();
    console.log("Here are all the bands");
    console.log(allBands);
    await bands.removeBand(band1._id);
    console.log("someGuys has been removed");
    const newAllBands = await bands.getAllBands();
    console.log("Here are all the bands");
    console.log(newAllBands);
    const updatedBand = await bands.updateBand(band2._id, "someGals", ["FirstGal", "SecondGal", "ThirdGal"], 2000, ["Jazz", "Rap"], "GuyMusic");
    console.log("someGals is now signed with GuyMusic");
    console.log(updatedBand);
    const db = await connection();
    await db.serverConfig.close();
    console.log("Done!");
};

main().catch((error) => {
    console.log(error);
});